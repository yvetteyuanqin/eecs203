if true
row=640;  col=480;
fin=fopen('cat.raw','r');
I1=fread(fin,row*col,'uint8=>uint8'); 

s=256;
H = zeros(s,1);
I2 =uint8(zeros(length(I1),1));
eqHist=zeros(s,1);


for c = 1:length(I1)
    H(I1(c)+1) = H(I1(c)+1)+1; 
end;
Kn=0;

for i = 1:length(H)
   
	Kn = Kn+  (H(i) /length(I1)); 
    eqHist(i) = Kn * 256;
end

for p = 1:length(I1)
    I2(p) = eqHist(I1(p)+1);
end

%fin2=fopen('cat.raw','r');
%I2=fread(fin2,row*col,'uint8=>uint8'); 

Z=reshape(I2,row,col);
Z=Z';
k=imshow(Z)
figure
I1;
plot(I1,eqHist(I1+1),'*')
axis([0 256 0 256])
title('Histogram equalization')
end